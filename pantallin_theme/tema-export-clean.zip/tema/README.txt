Archivos para exportar el tema Cyberpunk modificado.

Contenido:
- Tema/
- sensors_custom.py
- config-snippet.yaml

Instalacion en otra computadora:
1. Copia la carpeta `Tema` dentro de `res/themes/` del proyecto.
2. Haz respaldo del archivo `library/sensors/sensors_custom.py` de la otra computadora.
3. Reemplaza `library/sensors/sensors_custom.py` con el archivo `sensors_custom.py` de esta carpeta.
4. Ajusta `config.yaml` usando `config-snippet.yaml` como referencia.
5. Si usas Wi-Fi, revisa el nombre real de la interfaz. En esta maquina se usa `wlan0`.
6. Ejecuta `python3 -m pip install -r requirements.txt` si faltan dependencias.
7. Aplica el tema con `python3 main.py`.

Notas:
- El tema activo debe ser `Tema`.
- La velocidad Wi-Fi abajo usa el sensor custom `WifiLinkSpeed`.
- Si la velocidad muestra `--.- Mbps`, la otra maquina no pudo leerla con `iw`, `iwconfig` o `nmcli`.
